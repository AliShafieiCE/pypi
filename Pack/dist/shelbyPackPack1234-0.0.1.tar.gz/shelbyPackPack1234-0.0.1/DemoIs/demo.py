def DemoPrint():
	print("HIIIIII")